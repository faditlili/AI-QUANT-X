# FINAL_AUDIT — AI QUANT X (7.1.0 → 7.2.0)

**الحالة:** كل الاختبارات المنفذة (198) ناجحة في بيئة التدقيق، لكن **المشروع ليس مُثبَتاً كخالٍ من الأخطاء**:
لم تُشغَّل طبقة FastAPI/Uvicorn، ولا Telegram الحقيقي، ولا Binance الحي، ولا بناء Docker/Railway (انظر «ما لم يُختبر»).
لا يوجد في هذا التقرير أي ادعاء بربحية.

## 1. الأخطاء المكتشفة والإصلاحات
المفتاح: **[ح]** حرج مالياً، **[م]** متوسط، **[ص]** صغير. «الاختبار» = ملف/اختبار في `tests/` يثبت الإصلاح (والتجارب الطفرية في TEST_RESULTS تُثبت أنه يفشل إذا أُعيد الخطأ).

### إدارة المخاطر والمحاسبة
| # | الخطأ | الملف الأصلي | السبب الجذري | الإصلاح | الاختبار |
|---|---|---|---|---|---|
| 1 | **[ح]** المخاطرة الإجمالية تسمح حتى 20% (ضعف المواصفة) | `config.py`, `risk_manager.py` | `MAX_TOTAL_HEAT_PCT=20` والتحقق يقبل ≤20 | سقف صلب 10% في `accounting.portfolio_risk_cap` + `validate_config` يرفض >10 | `test_accounting.PortfolioLimits.test_hard_ceiling_even_if_config_raised`, `StaticChecks.test_config_rejects_unsafe_risk_settings` |
| 2 | **[ح]** الفحص غير ذري: الحجز المالي خارج المعاملة؛ `MAX_SAME_SIDE` معرّف ولا يُستخدم أبداً؛ عدد الصفقات/التكرار خارج المعاملة | `risk_manager.py`, `database.py` | فصل الفحص عن الكتابة | `Database.create_position` يعيد فحص **كل** الحدود داخل `BEGIN IMMEDIATE` عبر `accounting.check_portfolio_limits` ويعيد حساب المخاطرة بنفسه (لا يثق بقيمة المُستدعي) | `test_database_accounting.OpenAtomicity.*` (سباق 12 خيطاً، اتصالان على نفس الملف، مخاطرة مزوّرة) |
| 3 | **[ح]** المخاطرة الأصلية تضيع بعد الإغلاق الجزئي (R-multiple مشوَّه) | `database.partial_close`, `ui.py` | `risk_amount` تُخفَّض ولا يوجد حقل أصلي | عمود `initial_risk` ثابت؛ `risk_amount` = المتبقي فقط | `PartialClose.*` |
| 4 | **[ح]** تقرير الصفقة النهائي يفقد ربح/رسوم الأجزاء المغلقة | `database.close_position` | `gross_pnl`/`closing_fee` للجزء الأخير فقط | `partial_gross`, `partial_fees`, `fees_total`؛ `net_pnl` = الإجمالي الكامل | `test_partial_then_final_keeps_all_profit_and_fees`, `test_fees_never_counted_twice_across_random_runs` |
| 5 | **[ح]** الحجم يُحسب على سعر الإشارة بينما التعبئة بانزلاق؛ الرسوم غير مضمّنة في المخاطرة | `risk_manager.py` | ترتيب العمليات | الوقف/الهدف/الكمية من **سعر التعبئة المتوقع**، والمخاطرة تشمل رسوم الدخول والخروج وانزلاق الخروج | `Sizing.test_stop_out_never_exceeds_budget`, `test_actual_loss_at_stop_matches_risk` |
| 6 | **[ح]** لا دفتر حركات؛ الرصيد غير قابل للمطابقة | `database.py` | تحديث `state` فقط | جدول `ledger` + `integrity_report()` (رصيد=ledger، realized=سجل الصفقات) | `check_integrity` في كل الاختبارات + `test_financial_invariants` |
| 7 | **[ح]** سعر NaN يمر من `price<=0` | `paper_trading.py` | مقارنة NaN | `accounting.is_valid_price` في كل المسارات | `test_invalid_*` |
| 8 | **[م]** فحص الوقف بعد تحريكه بنفس السعر؛ إغلاق جزئي قابل للتكرار؛ صفقات قديمة بـ`initial_quantity=NULL` لا تُغلق جزئياً أبداً | `paper_trading.py`, `database.py` | | الوقف السابق يُفحص أولاً ثم يُحرَّك؛ `scale_out_done` ذري؛ ترحيل يملأ الحقول القديمة | `test_stop_check_uses_previous_stop...`, `test_repeated_scale_out_is_rejected`, `test_legacy_database_is_migrated...` |
| 9 | **[م]** Futures بلا رافعة/تصفية/Funding | `paper_trading.py` | غير مطبَّق | هامش معزول، سعر تصفية، Funding من التاريخ المسوّى (idempotent)، فصل Spot/Futures | `FundingAndFutures.*` |
| 10 | **[م]** عرض P&L الصفقات المفتوحة يرجع لسعر الدخول (ربح صفري وهمي) عند فشل السعر | `dashboard.py`, `ui.py` | قيمة افتراضية | آخر `mark_price` محفوظ + علامة `price_is_live` | (مراجعة كود؛ **غير مشغَّل** – FastAPI) |
| 11 | **[ص]** حد الخسارة اليومي: الحدّ بالضبط غير محجوب في `accounting` بينما `RiskManager` يحجبه | `accounting.py` | إشارة EPS معكوسة | `+ EPS` | وجده `test_daily_limit_and_bad_equity` أثناء التدقيق |
| 12 | **[ص]** المخاطرة المخزَّنة لصفقة جديدة تشمل رسوم دخول دُفعت أصلاً | `database.py` | | تُخزَّن بدونها (الفحص الأولي يشملها) | وجده `test_financial_invariants` |
| 13 | **[م]** حساب نصف-كيلي يعدّ الصفقات الصفرية خسائر | `brain.py` | `losses=len-wins` | `losses=[v<0]` | `test_dynamic_kelly...` |
| 14 | **[م]** لا حماية عند انقطاع البيانات | `engine.py` | | `DATA_STALE_SECONDS`: لا دخول؛ تنبيه إذا تعذّر تسعير كل الصفقات؛ لا إغلاق أعمى | `test_no_entry_on_market_data_outage`, `test_monitor_survives_total_price_outage...` |

### بيانات Binance والاتصال
| # | الخطأ | الإصلاح | الاختبار |
|---|---|---|---|
| 15 | **[ح]** قيم افتراضية مضلّلة عند الفشل: Funding=0.0، Fear&Greed=50، Breadth=50، دفتر أوامر «محايد»، Sentiment محايد، `news available=True` دائماً | الآن `None` = لا رأي؛ الدخول على Futures **محجوب** إذا تعذّر Funding | `test_market_data.test_funding_rate_none_on_failure...`, `OpenPath.test_context_carries_unknowns_as_none...`, `test_strategy_filter_blocks_futures_entry_without_funding` |
| 16 | **[ح]** سعر WebSocket بلا طابع زمني: سعر قديم يُستعمل للأبد في الوقف والدخول | طابع زمني + `PRICE_MAX_AGE_SECONDS` ثم REST | `test_stale_websocket_price_is_not_used` |
| 17 | **[ح]** الدخول بسعر آخر شمعة (قد يكون قديماً) عند غياب السعر الحي | الدخول محجوب | `test_no_entry_without_live_price` |
| 18 | **[م]** دفتر الأوامر والارتباط يستخدمان Futures دائماً حتى لصفقة Spot | مصدر السوق نفسه؛ الارتباط يفشل مغلقاً | `OrderBook.test_uses_requested_market`, `test_correlation_check_fails_closed` |
| 19 | **[م]** قواعد البورصة (step/min qty/min notional/tick) لا تُطبَّق؛ `exchangeInfo` يُخزَّن للأبد | `get_symbol_rules` + TTL 6 ساعات؛ الرمز بلا قواعد = لا صفقة | `Sizing.test_exchange_rules_respected`, `test_exchange_rules_unavailable_blocks_entry` |
| 20 | **[م]** طلب دفتر الأوامر يتجاوز مهلة الحظر (429)؛ لا كاش للشموع | كل الطلبات عبر `MarketData._get`؛ كاش شموع 20ث | `Retry.test_rate_limit_triggers_cooldown...`, `test_kline_cache_prevents_duplicate_requests` |
| 21 | **[م]** الماسح يعيد قائمة افتراضية عند الفشل ويُسجَّل كنجاح؛ `print` | يعيد `None` | `Scanner.test_failure_returns_none...` |
| 22 | **[م]** مدخلات API (symbol/interval/source) غير مُتحقَّق منها | regex + قوائم مسموحة | `Endpoints.test_symbol_and_interval_validation` (طبقة MarketData) |
| 23 | **[ص]** شموع ناقصة/فاسدة تُصلَح بصمت فتُزيح المؤشرات | المسار الحي `strict`: يرفض الفجوات والشموع غير الصالحة | `Indicators.test_gap_in_live_candles_is_detected`, `test_bad_data_rejected_or_cleaned...` |

### Backtest، الذكاء الاصطناعي
| # | الخطأ | الإصلاح | الاختبار |
|---|---|---|---|
| 24 | **[ح]** Backtest بمنطق مختلف عن الحي: مركز واحد، حجم/وقف مختلف، بلا سقف 10%، هدف بلا انزلاق، نقل الوقف للتعادل داخل نفس الشمعة | أُعيد بناؤه على `accounting` نفسه: محفظة متعددة الرموز، سقف 10%، `MAX_SAME_SIDE`، رسوم/انزلاق على كل خروج، Funding، تصفية، حمايات (خسائر متتالية/تراجع/إيقاف استراتيجية/قفل زوج/تهدئة)، دخول عند **افتتاح الشمعة التالية** | `test_indicators_backtest.Backtest.*` |
| 25 | **[ح]** وقف وهدف في الشمعة نفسها | افتراض محافظ معلن وموحَّد: **الوقف أولاً**؛ فجوة الافتتاح تُنفَّذ عند الافتتاح؛ تغيّر الوقف يسري من الشمعة التالية | `test_same_bar_stop_and_target_resolves_to_stop` |
| 26 | **[ح]** Look-ahead | اختبار قطع المستقبل: الصفقات السابقة لا تتغير | `test_no_lookahead_truncating_the_future...`, `Indicators.test_no_lookahead_...` |
| 27 | **[م]** اختبار دلالة ML ضعيف (+1 نقطة فقط) | يتطلب z ≥ 1.64 على فترة اختبار لاحقة زمنياً مع embargo | `MLFilter.test_holdout_is_later...`, `test_pure_noise_is_not_declared_a_valid_edge` |
| 28 | **[م]** عتبات المعايرة التلقائية ضعيفة (3 صفقات، PF≥1.0) | 10 صفقات و PF≥1.2 + ملاحظة تعدد الاختبارات | `Optimizer.*` |
| 29 | **[م]** تعارض إشارات استراتيجيات متعاكسة يُحلّ بدون هامش | `CONFLICT_MIN_SCORE_GAP` | (مغطّى جزئياً عبر اختبارات المحرك؛ **لا اختبار مخصص**) |

### الأمان والتشغيل
| # | الخطأ | الإصلاح | الاختبار |
|---|---|---|---|
| 30 | **[م]** مسار `/` مكرر (`ui.py` و`dashboard.py`) و`ui_router` مُضمَّن مرتين في `main.py` | اللوحة القديمة نُقلت إلى `/legacy`؛ كل router مرة واحدة | `test_no_duplicate_routes_and_routers_included_once` |
| 31 | **[ح]** سجل الوصول يطبع `?key=<DASHBOARD_KEY>` | `access_log=False` | (مراجعة كود) |
| 32 | **[م]** تجاوز قفل المحاولات بتزوير أول قيمة في `X-Forwarded-For` | آخر قفزة (المضافة من الوكيل) | `Security.test_client_ip_...` |
| 33 | **[ح]** `DASHBOARD_KEY` فارغ = أزرار التحكم مفتوحة للجميع | POST محجوبة ما لم `ALLOW_INSECURE_DASHBOARD=true` | (مراجعة كود؛ الـmiddleware **غير مشغَّل**) |
| 34 | **[م]** تيليجرام: رد/تنبيه قد يكسر المحرك؛ `int()` على callback غير صالح؛ `net_pnl=None` | إرسال محمي، تحليل آمن، إغلاق ببيانات حية فقط | `Telegram.*` |
| 35 | **[م]** `dockerignore`/`gitignore` في الأرشيف بلا نقطة ⇒ **لا يعملان** (قد تدخل `.env`/`*.db` الصورة) | أُعيدت تسميتها `.dockerignore`/`.gitignore` | `test_deployment_files_consistent` |
| 36 | **[ص]** لا HEALTHCHECK في Dockerfile؛ `.env.example` ناقص؛ README شبه فارغ | أُضيفت؛ `requirements-dev.txt`, `pytest.ini` | نفس الاختبار |

## 2. ما بقي دون حل / قيود معروفة
1. **Futures مبسَّط** (لا MMR متدرّج، لا رسوم تصفية/صندوق تأمين، Mark Price = آخر سعر، لا Cross/Hedge). موثق في README.
2. **Backtest متفائل نسبياً**: لا يطبّق ML، sentiment، order book، Fear&Greed، breadth، فلتر Funding، تقريب lot/tick (لا بيانات تاريخية لها). مذكور في كل تقرير (`limitations`). Funding يُحتسب فقط إذا توفر تاريخه.
3. **مؤشرات الحي مقابل Backtest**: الحي يحسب على آخر 200 شمعة والـBacktest على سلسلة أطول (تحمية EWM تختلف قليلاً)؛ `vwap` مثبّت على نافذة 24 لتقليل الفرق.
4. **الإحصاء**: المعايرة التلقائية تختار الأفضل بين عدة تركيبات؛ حتى مع التحقق الخارجي تبقى مخاطر الاختبارات المتعددة. عملية Walk-forward المتوفرة لا تُضبط عليها معاملات.
5. **حجم المخاطرة الديناميكي (نصف كيلي)** له حد أدنى 0.5% حتى مع توقّع سلبي (قرار تصميم: عدم إيقاف النظام بسبب عينة صغيرة)؛ أوقِف يدوياً إن لزم.
6. بعد ربح غير محقق كبير ثم هبوط حقوق الملكية يمكن أن تتجاوز نسبة المخاطرة المفتوحة 10% من Equity **الحالية** (السقف يُفحص عند القبول، وهو سلوك متوقع؛ الصفقات الجديدة تُحجب).
7. رسوم Spot تُخصم من USDT وليس من الأصل المستلم؛ لا BNB discount.
8. تيار `wss://fstream.binance.com/ws/!ticker@arr`: لم أستطع التحقق حياً من استمراره؛ الـREST احتياطي تلقائي، والرابط قابل للضبط (`BINANCE_WS_URL`).
9. HTML القديم (`/legacy`، ~800 سطر داخل `dashboard.py`) فُحص لتهريب HTML (`esc`) وتطابق الـAPI فقط، لا سطراً سطراً.

## 3. ما لم يُختبر فعلياً (بصراحة)
* **FastAPI/Uvicorn غير مثبّتَين في بيئتي (لا شبكة)**: `main.py`، الـmiddleware، مسارات `ui.py`/`dashboard.py` لم تُنفَّذ؛ فُحصت بالقراءة، و`ast` (لا مسارات مكررة، كل endpoint تستدعيه JS موجود) و`node --check` لملفات JS.
* **Telegram الحقيقي**: الاختبارات تعمل على بدائل (stubs) لمكتبة `python-telegram-bot`؛ لم يُتحقق من توافق v21/22.
* **aiohttp الحقيقي وBinance الحي**: طبقة HTTP محاكاة بجلسة وهمية (استجابات 200/429/5xx/timeout)؛ لم يُجرَ أي اتصال حي ولا WebSocket حقيقي.
* **pytest** غير متاح؛ نُفِّذت بـ`python -m unittest` (الاختبارات كلها `unittest.TestCase` فتعمل تحت pytest، لكن لم أشغّله).
* **Docker/Railway**: لم يُبنَ الصورة ولا نُشر؛ **Python 3.12 / pandas 3.0.x** في بيئتي بينما Dockerfile على 3.11 و`requirements` يسمح بـpandas 2.x و3.x (لم تُجرَّب 2.x).
