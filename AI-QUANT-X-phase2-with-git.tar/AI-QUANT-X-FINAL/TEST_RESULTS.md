# TEST_RESULTS

## البيئة (حقيقية)
* Python 3.12، pandas 3.0.x، numpy، scikit-learn، joblib، Node (لفحص JS). **بدون شبكة.**
* **غير مثبّت:** pytest، fastapi، uvicorn، aiohttp، python-telegram-bot، websockets، nltk.
  لذلك: الاختبارات `unittest.TestCase` تُشغَّل بـ`python -m unittest discover -s tests -v` (وهي متوافقة مع pytest ولم أشغّل pytest).
  حيث تغيب aiohttp/websockets/telegram تُحمَّل بدائل خفيفة من `tests/_env.py` (لا تُستخدم إن كانت الحقيقية مثبّتة). **لا اتصالات حية في أي اختبار.**

## النتيجة
* `python -m compileall -q .` → **OK**
* `python -m unittest discover -s tests` → **Ran 198 tests in ~52s — OK** (0 فشل، 0 خطأ، 0 تخطي). أُعيد التشغيل مرتين بنفس النتيجة.
* `node --check pro_*.js` (7 ملفات) → OK.

| ملف الاختبار | العدد | ما يغطيه |
|---|---|---|
| test_accounting.py | 27 | رسوم، انزلاق، PnL، حجم المركز، المخاطرة، سقف 10%، المثال 200→20 و15+5، تصفية، Funding، حدود المحفظة |
| test_database_accounting.py | 28 | ذرية الفتح (سباق خيوط واتصالين)، محاسبة الإغلاق الكامل والجزئي، الدفتر، إعادة التشغيل، ترحيل قاعدة قديمة، WAL |
| test_trading_risk.py | 27 | وقف/هدف/Scale-out/Trailing، حد يومي، خسائر متتالية، تراجع، انقطاع بيانات، Spot long-only |
| test_indicators_backtest.py | 25 | مؤشرات (مرجعية)، عدم وجود look-ahead، شموع ناقصة، Backtest (وقف أولاً، سقف 10%، تصفية، Funding، قطع المستقبل) |
| test_market_data.py | 21 | HTTP 5xx/4xx/429/timeout/JSON فاسد، كاش، تحليل الشموع، Funding=None، قواعد الرمز، لا endpoints للأوامر |
| test_engine_integration.py | 23 | Engine+Market+Decision+Risk+DB+Notifier: فتح، حجب، انقطاع، سعر قديم، تعطل الإشعارات، Funding، إعادة تشغيل |
| test_ml_optimizer_context.py | 15 | ML (embargo، ضجيج ≠ ميزة)، دفتر الأوامر، sentiment، scanner، optimizer |
| test_security_telegram_static.py | 27 | الأمان، صلاحيات Telegram لكل الأوامر، فحوص ثابتة (مسارات، استيرادات، أسرار، PAPER، ملفات النشر، JS) |
| test_financial_invariants.py | 5 | محاكاة عشوائية مبذورة (12+6+4 تشغيلات، حتى 300 خطوة، تضم إعادة تشغيل وتصفية) تفحص الثوابت بعد **كل** خطوة |
| **المجموع** | **198** | |

## فحص جودة الاختبارات (Mutation sanity)
حقنتُ أخطاء مقصودة في نسخة معزولة للتأكد من أن الاختبارات تفشل فعلاً:

| # | الخطأ المحقون (في نسخة معزولة) | الاختبارات التي شُغِّلت | النتيجة |
|---|---|---|---|
| A | إلغاء فحص سقف المخاطرة الإجمالي في `check_portfolio_limits` | test_accounting | فشل 1 (كُشف) |
| B | `create_position` لا يرفض عند خرق الحدود | test_database_accounting | فشل 3 (كُشف) |
| C | إزالة حارس الإغلاق الجزئي المكرر في DB | test_database_accounting | فشل 1 (كُشف) |
| D | إلغاء انزلاق الخروج | test_database_accounting | فشل 3 (كُشف) |
| E | إلغاء حماية انقطاع البيانات | test_trading_risk | فشل 1 (كُشف) |
| F | رفع السقف إلى ×2 | test_accounting | فشل 3 (كُشف) |
| G | احتساب رسوم الإغلاق مرتين | test_database_accounting | فشل 8 (كُشف) |
| H | فقدان ربح الإغلاق الجزئي | test_database_accounting | فشل 2 (كُشف) |
| I | إزالة حارس Scale-out المكرر في `PaperTrader` فقط | test_trading_risk | **لم يُكشف** — متوقع: حارس DB الذري يغطيه (دفاع متعدد الطبقات؛ المطفِّر C يُكشف عند إزالة حارس DB) |

خلال التطوير كشفت الاختبارات نفسها ثلاثة عيوب حقيقية في الكود وأصلحتها (حدّ الخسارة اليومي على الحد بالضبط، تضمين رسوم دخول مدفوعة في المخاطرة المخزّنة، وانقطاع حقول التقرير في Backtest). كما صُحّحت أخطاء في اختبارات كتبتُها أنا (إعداد أرصدة لا يسمح بالتنفيذ) — دون إضعاف أي تأكيد على سلوك النظام.

## ما لم يُشغَّل (لا تعتبره ناجحاً)
1. مسارات FastAPI/الـmiddleware/ui/dashboard/main (لا FastAPI): فُحصت ثابتاً فقط (`ast`، توافق endpoints مع JS، `node --check`).
2. Binance الحي، WebSocket الحقيقي، حدود المعدل الفعلية، حظر IP.
3. مكتبة Telegram الحقيقية وعرض الأزرار.
4. بناء Docker ونشر Railway وVolume وHealth check الفعلي.
5. pytest نفسه، Python 3.11، pandas 2.x.
6. تشغيل طويل (أيام) لاستقرار الذاكرة/الاتصال.

## ملاحظة على نتائج Backtest في الاختبارات
بيانات الاختبار **اصطناعية** (مشي عشوائي مبذور) وتُستخدم فقط للتحقق من سلامة المنطق (لا look-ahead، سقف 10%، ترتيب الوقف). لا تدل على أي ربحية.

## Appendix: المخرجات الخام
```
# raw output
Tue Nov 17 11:01:56 UTC 2026
Python 3.12.3
pandas 3.0.6 numpy 2.5.4 sklearn 1.9.1

compileall: OK

test_fee_rates_are_per_market (test_accounting.FillsAndPnl.test_fee_rates_are_per_market) ... ok
test_floor_to_step_is_exact (test_accounting.FillsAndPnl.test_floor_to_step_is_exact) ... ok
test_funding_direction (test_accounting.FillsAndPnl.test_funding_direction) ... ok
test_gross_pnl_signs (test_accounting.FillsAndPnl.test_gross_pnl_signs) ... ok
test_liquidation_price (test_accounting.FillsAndPnl.test_liquidation_price) ... ok
test_slippage_is_always_adverse (test_accounting.FillsAndPnl.test_slippage_is_always_adverse) ... ok
test_cap_tracks_equity (test_accounting.PortfolioLimits.test_cap_tracks_equity) ... ok
test_daily_limit_and_bad_equity (test_accounting.PortfolioLimits.test_daily_limit_and_bad_equity) ... ok
test_duplicate_symbol_across_markets (test_accounting.PortfolioLimits.test_duplicate_symbol_across_markets) ... ok
test_hard_ceiling_even_if_config_raised (test_accounting.PortfolioLimits.test_hard_ceiling_even_if_config_raised) ... ok
test_max_open_positions (test_accounting.PortfolioLimits.test_max_open_positions) ... ok
test_max_same_side (test_accounting.PortfolioLimits.test_max_same_side) ... ok
test_spec_example_15_used_blocks_over_5 (test_accounting.PortfolioLimits.test_spec_example_15_used_blocks_over_5) ... ok
test_spec_example_200_equity_cap_20 (test_accounting.PortfolioLimits.test_spec_example_200_equity_cap_20) ... ok
test_spot_short_rejected_and_cash_checked (test_accounting.PortfolioLimits.test_spot_short_rejected_and_cash_checked) ... ok
test_actual_loss_at_stop_matches_risk (test_accounting.Sizing.test_actual_loss_at_stop_matches_risk) ... ok
test_below_min_notional_rejected (test_accounting.Sizing.test_below_min_notional_rejected) ... ok
test_cash_limits_quantity (test_accounting.Sizing.test_cash_limits_quantity) ... ok
test_exchange_rules_respected (test_accounting.Sizing.test_exchange_rules_respected) ... ok
test_leverage_reduces_margin_not_risk (test_accounting.Sizing.test_leverage_reduces_margin_not_risk) ... ok
test_rejects_bad_inputs (test_accounting.Sizing.test_rejects_bad_inputs) ... ok
test_spot_ignores_leverage (test_accounting.Sizing.test_spot_ignores_leverage) ... ok
test_stop_out_never_exceeds_budget (test_accounting.Sizing.test_stop_out_never_exceeds_budget) ... ok
test_entry_fee_added_for_candidates_only (test_accounting.StopRisk.test_entry_fee_added_for_candidates_only) ... ok
test_locked_profit_is_zero_risk (test_accounting.StopRisk.test_locked_profit_is_zero_risk) ... ok
test_long_includes_exit_costs (test_accounting.StopRisk.test_long_includes_exit_costs) ... ok
test_short (test_accounting.StopRisk.test_short) ... ok
test_double_close_is_noop (test_database_accounting.ClosingAccounting.test_double_close_is_noop) ... ok
test_fees_are_not_charged_twice (test_database_accounting.ClosingAccounting.test_fees_are_not_charged_twice) ... ok
test_full_close_net_equals_gross_minus_all_fees (test_database_accounting.ClosingAccounting.test_full_close_net_equals_gross_minus_all_fees) ... ok
test_invalid_exit_price_refused (test_database_accounting.ClosingAccounting.test_invalid_exit_price_refused) ... Refusing to close 1 at invalid price 0.0
Refusing to close 1 at invalid price -5.0
Refusing to close 1 at invalid price nan
Refusing to close 1 at invalid price inf
ok
test_short_profit_and_loss (test_database_accounting.ClosingAccounting.test_short_profit_and_loss) ... ok
test_funding_idempotent_per_event (test_database_accounting.FundingAndFutures.test_funding_idempotent_per_event) ... ok
test_funding_never_applied_to_spot (test_database_accounting.FundingAndFutures.test_funding_never_applied_to_spot) ... ok
test_funding_paid_reduces_cash_and_net (test_database_accounting.FundingAndFutures.test_funding_paid_reduces_cash_and_net) ... ok
test_leverage_position_margin_and_liquidation (test_database_accounting.FundingAndFutures.test_leverage_position_margin_and_liquidation) ... ok
test_concurrent_opens_never_exceed_aggregate_cap (test_database_accounting.OpenAtomicity.test_concurrent_opens_never_exceed_aggregate_cap) ... ok
test_db_gate_cannot_be_bypassed_by_forged_risk (test_database_accounting.OpenAtomicity.test_db_gate_cannot_be_bypassed_by_forged_risk) ... ok
test_failed_open_changes_nothing (test_database_accounting.OpenAtomicity.test_failed_open_changes_nothing) ... ok
test_open_records_everything_and_reserves_cash (test_database_accounting.OpenAtomicity.test_open_records_everything_and_reserves_cash) ... ok
test_second_open_of_same_symbol_rejected_in_db (test_database_accounting.OpenAtomicity.test_second_open_of_same_symbol_rejected_in_db) ... ok
test_two_database_connections_race_is_serialised_by_sqlite (test_database_accounting.OpenAtomicity.test_two_database_connections_race_is_serialised_by_sqlite) ... ok
test_losing_partial_then_stop (test_database_accounting.PartialClose.test_losing_partial_then_stop) ... ok
test_partial_cannot_close_everything_or_negative (test_database_accounting.PartialClose.test_partial_cannot_close_everything_or_negative) ... ok
test_partial_then_final_keeps_all_profit_and_fees (test_database_accounting.PartialClose.test_partial_then_final_keeps_all_profit_and_fees) ... ok
test_repeated_scale_out_is_rejected (test_database_accounting.PartialClose.test_repeated_scale_out_is_rejected) ... ok
test_risk_after_partial_uses_current_stop_and_remaining_qty (test_database_accounting.PartialClose.test_risk_after_partial_uses_current_stop_and_remaining_qty) ... ok
test_performance_report_matches_trade_rows (test_database_accounting.Performance.test_performance_report_matches_trade_rows) ... ok
test_gap_through_stop_after_restart_closes_at_gap_price (test_database_accounting.PersistenceAndMigration.test_gap_through_stop_after_restart_closes_at_gap_price) ... ok
test_legacy_database_is_migrated_without_losing_history (test_database_accounting.PersistenceAndMigration.test_legacy_database_is_migrated_without_losing_history) ... ok
test_restart_keeps_open_positions_and_stops (test_database_accounting.PersistenceAndMigration.test_restart_keeps_open_positions_and_stops) ... ok
test_unwritable_path_falls_back_and_reports_it (test_database_accounting.PersistenceAndMigration.test_unwritable_path_falls_back_and_reports_it) ... DB path /proc/definitely/not/writable/x.db not writable; using data/ai_quant_x.db (NOT persistent on Railway).
ok
test_wal_mode_and_foreign_keys (test_database_accounting.PersistenceAndMigration.test_wal_mode_and_foreign_keys) ... ok
test_equity_uses_marks_and_ignores_invalid (test_database_accounting.StopAndMarks.test_equity_uses_marks_and_ignores_invalid) ... ok
test_stop_only_tightens (test_database_accounting.StopAndMarks.test_stop_only_tightens) ... ok
test_funding_settled_for_open_futures_positions_only (test_engine_integration.MonitorPath.test_funding_settled_for_open_futures_positions_only) ... ok
test_monitor_survives_total_price_outage_and_alerts_once (test_engine_integration.MonitorPath.test_monitor_survives_total_price_outage_and_alerts_once) ... No prices for open positions for 0s: stops are NOT being monitored
ok
test_restart_with_open_positions_resumes_monitoring (test_engine_integration.MonitorPath.test_restart_with_open_positions_resumes_monitoring) ... ok
test_scale_out_event_is_notified (test_engine_integration.MonitorPath.test_scale_out_event_is_notified) ... ok
test_scan_once_runs_both_markets_and_snapshots_equity (test_engine_integration.MonitorPath.test_scan_once_runs_both_markets_and_snapshots_equity) ... Symbol scanner failed: '_Dummy' object does not support the asynchronous context manager protocol
ok
test_stop_loss_closes_and_notifies (test_engine_integration.MonitorPath.test_stop_loss_closes_and_notifies) ... ok
test_candle_fetch_failure_means_no_trade_and_error_propagates (test_engine_integration.OpenPath.test_candle_fetch_failure_means_no_trade_and_error_propagates) ... ok
test_context_carries_unknowns_as_none_not_fake_neutrals (test_engine_integration.OpenPath.test_context_carries_unknowns_as_none_not_fake_neutrals) ... ok
test_cooldown_and_pair_lock (test_engine_integration.OpenPath.test_cooldown_and_pair_lock) ... ok
test_correlation_check_fails_closed (test_engine_integration.OpenPath.test_correlation_check_fails_closed) ... ok
test_exchange_rules_unavailable_blocks_entry (test_engine_integration.OpenPath.test_exchange_rules_unavailable_blocks_entry) ... Symbol rules unavailable futures/SOLUSDT: no exchange info
ok
test_highly_correlated_symbol_blocked (test_engine_integration.OpenPath.test_highly_correlated_symbol_blocked) ... ok
test_hold_signal_records_decision_only (test_engine_integration.OpenPath.test_hold_signal_records_decision_only) ... ok
test_missing_funding_is_passed_as_none_for_futures_and_absent_for_spot (test_engine_integration.OpenPath.test_missing_funding_is_passed_as_none_for_futures_and_absent_for_spot) ... ok
test_no_entry_on_market_data_outage (test_engine_integration.OpenPath.test_no_entry_on_market_data_outage) ... ok
test_no_entry_without_live_price (test_engine_integration.OpenPath.test_no_entry_without_live_price) ... ok
test_notifier_failure_cannot_break_trading (test_engine_integration.OpenPath.test_notifier_failure_cannot_break_trading) ... Notification notify_trade_opened failed: telegram down
ok
test_paused_engine_never_opens (test_engine_integration.OpenPath.test_paused_engine_never_opens) ... ok
test_same_symbol_not_opened_twice (test_engine_integration.OpenPath.test_same_symbol_not_opened_twice) ... ok
test_signal_opens_a_persisted_position_with_notification (test_engine_integration.OpenPath.test_signal_opens_a_persisted_position_with_notification) ... ok
test_stale_setup_skipped (test_engine_integration.OpenPath.test_stale_setup_skipped) ... ok
test_stale_websocket_price_is_not_used (test_engine_integration.OpenPath.test_stale_websocket_price_is_not_used) ... ok
test_strategy_filter_blocks_futures_entry_without_funding (test_engine_integration.OpenPath.test_strategy_filter_blocks_futures_entry_without_funding) ... ok
test_fees_never_counted_twice_across_random_runs (test_financial_invariants.Invariants.test_fees_never_counted_twice_across_random_runs) ... ok
test_portfolio_value_matches_trade_record_after_many_partials (test_financial_invariants.Invariants.test_portfolio_value_matches_trade_record_after_many_partials) ... ok
test_random_runs_1x (test_financial_invariants.Invariants.test_random_runs_1x) ... ok
test_random_runs_leveraged_futures (test_financial_invariants.Invariants.test_random_runs_leveraged_futures) ... ok
test_spot_only (test_financial_invariants.Invariants.test_spot_only) ... ok
test_costs_matter (test_indicators_backtest.Backtest.test_costs_matter) ... ok
test_deterministic (test_indicators_backtest.Backtest.test_deterministic) ... ok
test_equity_curve_reconciles_with_trades (test_indicators_backtest.Backtest.test_equity_curve_reconciles_with_trades) ... ok
test_funding_cost_is_reported_when_supplied (test_indicators_backtest.Backtest.test_funding_cost_is_reported_when_supplied) ... ok
test_leverage_liquidation_caps_loss_at_margin (test_indicators_backtest.Backtest.test_leverage_liquidation_caps_loss_at_margin) ... ok
test_never_more_than_max_positions_and_same_side (test_indicators_backtest.Backtest.test_never_more_than_max_positions_and_same_side) ... ok
test_no_lookahead_truncating_the_future_does_not_change_past_trades (test_indicators_backtest.Backtest.test_no_lookahead_truncating_the_future_does_not_change_past_trades) ... ok
test_not_enough_history_raises (test_indicators_backtest.Backtest.test_not_enough_history_raises) ... ok
test_open_risk_never_exceeds_ten_percent_of_equity (test_indicators_backtest.Backtest.test_open_risk_never_exceeds_ten_percent_of_equity) ... ok
test_report_declares_assumptions (test_indicators_backtest.Backtest.test_report_declares_assumptions) ... ok
test_same_bar_stop_and_target_resolves_to_stop (test_indicators_backtest.Backtest.test_same_bar_stop_and_target_resolves_to_stop) ... ok
test_spot_backtest_is_long_only (test_indicators_backtest.Backtest.test_spot_backtest_is_long_only) ... ok
test_trades_enter_at_next_open_with_adverse_slippage (test_indicators_backtest.Backtest.test_trades_enter_at_next_open_with_adverse_slippage) ... ok
test_walk_forward_has_disjoint_out_of_sample_folds (test_indicators_backtest.Backtest.test_walk_forward_has_disjoint_out_of_sample_folds) ... ok
test_atr_matches_manual_wilder (test_indicators_backtest.Indicators.test_atr_matches_manual_wilder) ... ok
test_bad_data_rejected_or_cleaned_never_silently_used (test_indicators_backtest.Indicators.test_bad_data_rejected_or_cleaned_never_silently_used) ... ok
test_direction (test_indicators_backtest.Indicators.test_direction) ... ok
test_duplicate_timestamps_removed (test_indicators_backtest.Indicators.test_duplicate_timestamps_removed) ... ok
test_ema_matches_reference (test_indicators_backtest.Indicators.test_ema_matches_reference) ... ok
test_flat_market_is_neutral_not_nan (test_indicators_backtest.Indicators.test_flat_market_is_neutral_not_nan) ... ok
test_gap_in_live_candles_is_detected (test_indicators_backtest.Indicators.test_gap_in_live_candles_is_detected) ... ok
test_no_lookahead_future_rows_do_not_change_past_values (test_indicators_backtest.Indicators.test_no_lookahead_future_rows_do_not_change_past_values) ... ok
test_rsi_extremes (test_indicators_backtest.Indicators.test_rsi_extremes) ... ok
test_series_matches_function_on_every_bar (test_indicators_backtest.VolumeAnomaly.test_series_matches_function_on_every_bar) ... ok
test_spike_detected_with_baseline_excluding_itself (test_indicators_backtest.VolumeAnomaly.test_spike_detected_with_baseline_excluding_itself) ... ok
test_breadth_none_when_unavailable (test_market_data.Endpoints.test_breadth_none_when_unavailable) ... Breadth unavailable (futures): HTTP 500: x
ok
test_eligible_symbols_filters_by_market (test_market_data.Endpoints.test_eligible_symbols_filters_by_market) ... ok
test_fear_greed_none_not_fifty_on_failure (test_market_data.Endpoints.test_fear_greed_none_not_fifty_on_failure) ... ok
test_funding_history_sorted_and_malformed_rows_skipped (test_market_data.Endpoints.test_funding_history_sorted_and_malformed_rows_skipped) ... ok
test_funding_rate_none_on_failure_and_zero_is_real_zero (test_market_data.Endpoints.test_funding_rate_none_on_failure_and_zero_is_real_zero) ... ok
test_kline_cache_prevents_duplicate_requests (test_market_data.Endpoints.test_kline_cache_prevents_duplicate_requests) ... ok
test_klines_drop_forming_candle_and_enforce_minimum (test_market_data.Endpoints.test_klines_drop_forming_candle_and_enforce_minimum) ... ok
test_last_prices_filter_invalid (test_market_data.Endpoints.test_last_prices_filter_invalid) ... ok
test_malformed_kline_row_raises (test_market_data.Endpoints.test_malformed_kline_row_raises) ... ok
test_no_trading_or_account_endpoints_anywhere (test_market_data.Endpoints.test_no_trading_or_account_endpoints_anywhere) ... ok
test_spot_and_futures_use_their_own_hosts_and_paths (test_market_data.Endpoints.test_spot_and_futures_use_their_own_hosts_and_paths) ... ok
test_symbol_and_interval_validation (test_market_data.Endpoints.test_symbol_and_interval_validation) ... ok
test_symbol_rules_parser (test_market_data.Endpoints.test_symbol_rules_parser) ... ok
test_tickers_cached_and_invalid_dropped (test_market_data.Endpoints.test_tickers_cached_and_invalid_dropped) ... ok
test_4xx_not_retried (test_market_data.Retry.test_4xx_not_retried) ... ok
test_client_error_and_timeout_become_marketdataerror (test_market_data.Retry.test_client_error_and_timeout_become_marketdataerror) ... ok
test_http_500_is_retried_then_succeeds (test_market_data.Retry.test_http_500_is_retried_then_succeeds) ... ok
test_invalid_json_is_an_error_not_empty_data (test_market_data.Retry.test_invalid_json_is_an_error_not_empty_data) ... ok
test_persistent_500_raises_after_bounded_attempts (test_market_data.Retry.test_persistent_500_raises_after_bounded_attempts) ... ok
test_rate_limit_triggers_cooldown_and_blocks_further_calls (test_market_data.Retry.test_rate_limit_triggers_cooldown_and_blocks_further_calls) ... ok
test_success_updates_freshness (test_market_data.Retry.test_success_updates_freshness) ... ok
test_features_are_scale_free (test_ml_optimizer_context.MLFilter.test_features_are_scale_free) ... ok
test_holdout_is_later_in_time_than_training (test_ml_optimizer_context.MLFilter.test_holdout_is_later_in_time_than_training) ... ok
test_invalid_model_returns_none_even_though_file_exists (test_ml_optimizer_context.MLFilter.test_invalid_model_returns_none_even_though_file_exists) ... ok
test_missing_snapshot_fields_give_none (test_ml_optimizer_context.MLFilter.test_missing_snapshot_fields_give_none) ... ok
test_no_model_means_no_opinion (test_ml_optimizer_context.MLFilter.test_no_model_means_no_opinion) ... ok
test_pure_noise_is_not_declared_a_valid_edge (test_ml_optimizer_context.MLFilter.test_pure_noise_is_not_declared_a_valid_edge) ... ok
test_too_little_data_returns_none (test_ml_optimizer_context.MLFilter.test_too_little_data_returns_none) ... [ML] not enough data to train
[ML] not enough data to train
ok
test_noise_rarely_passes_validation (test_ml_optimizer_context.Optimizer.test_noise_rarely_passes_validation) ... ok
test_sweep_uses_held_out_validation_and_never_mutates_global_params (test_ml_optimizer_context.Optimizer.test_sweep_uses_held_out_validation_and_never_mutates_global_params) ... ok
test_labels (test_ml_optimizer_context.OrderBook.test_labels) ... ok
test_none_not_neutral_when_unavailable (test_ml_optimizer_context.OrderBook.test_none_not_neutral_when_unavailable) ... ok
test_uses_requested_market (test_ml_optimizer_context.OrderBook.test_uses_requested_market) ... ok
test_failure_returns_none_so_the_watchlist_is_kept (test_ml_optimizer_context.Scanner.test_failure_returns_none_so_the_watchlist_is_kept) ... Symbol scanner: HTTP 500
ok
test_analyze_scores_headlines (test_ml_optimizer_context.Sentiment.test_analyze_scores_headlines) ... ok
test_unavailable_is_none_not_neutral (test_ml_optimizer_context.Sentiment.test_unavailable_is_none_not_neutral) ... ok
test_client_ip_uses_proxy_appended_hop_not_spoofable_first_hop (test_security_telegram_static.Security.test_client_ip_uses_proxy_appended_hop_not_spoofable_first_hop) ... ok
test_credentials (test_security_telegram_static.Security.test_credentials) ... ok
test_lockout_and_expiry (test_security_telegram_static.Security.test_lockout_and_expiry) ... ok
test_session_token_never_contains_key (test_security_telegram_static.Security.test_session_token_never_contains_key) ... ok
test_all_python_compiles (test_security_telegram_static.StaticChecks.test_all_python_compiles) ... ok
test_config_rejects_unsafe_risk_settings (test_security_telegram_static.StaticChecks.test_config_rejects_unsafe_risk_settings) ... ok
test_deployment_files_consistent (test_security_telegram_static.StaticChecks.test_deployment_files_consistent) ... ok
test_env_example_has_no_filled_secrets (test_security_telegram_static.StaticChecks.test_env_example_has_no_filled_secrets) ... ok
test_every_endpoint_the_frontend_calls_exists (test_security_telegram_static.StaticChecks.test_every_endpoint_the_frontend_calls_exists) ... ok
test_every_import_resolves_to_a_project_module_or_declared_dependency (test_security_telegram_static.StaticChecks.test_every_import_resolves_to_a_project_module_or_declared_dependency) ... ok
test_javascript_syntax (test_security_telegram_static.StaticChecks.test_javascript_syntax) ... ok
test_no_duplicate_routes_and_routers_included_once (test_security_telegram_static.StaticChecks.test_no_duplicate_routes_and_routers_included_once) ... ok
test_no_secrets_in_repository (test_security_telegram_static.StaticChecks.test_no_secrets_in_repository) ... ok
test_paper_only_no_exchange_credentials_or_order_calls (test_security_telegram_static.StaticChecks.test_paper_only_no_exchange_credentials_or_order_calls) ... ok
test_project_internal_names_exist (test_security_telegram_static.StaticChecks.test_project_internal_names_exist)
Every `from module import name` between project modules must name something that exists. ... ok
test_admin_commands_work (test_security_telegram_static.Telegram.test_admin_commands_work) ... ok
test_callbacks_reject_non_admin (test_security_telegram_static.Telegram.test_callbacks_reject_non_admin) ... ok
test_close_callback_closes (test_security_telegram_static.Telegram.test_close_callback_closes) ... ok
test_close_callback_garbage_and_no_price (test_security_telegram_static.Telegram.test_close_callback_garbage_and_no_price) ... ok
test_disabled_telegram_never_blocks_engine (test_security_telegram_static.Telegram.test_disabled_telegram_never_blocks_engine) ... ok
test_every_command_rejects_non_admin_without_side_effects (test_security_telegram_static.Telegram.test_every_command_rejects_non_admin_without_side_effects) ... ok
test_forceexit_bad_args_do_not_crash (test_security_telegram_static.Telegram.test_forceexit_bad_args_do_not_crash) ... ok
test_forceexit_closes_with_live_price_and_notifies (test_security_telegram_static.Telegram.test_forceexit_closes_with_live_price_and_notifies) ... ok
test_missing_user_is_rejected (test_security_telegram_static.Telegram.test_missing_user_is_rejected) ... ok
test_notification_content (test_security_telegram_static.Telegram.test_notification_content) ... ok
test_pause_resume_toggle (test_security_telegram_static.Telegram.test_pause_resume_toggle) ... ok
test_risk_report_matches_risk_manager (test_security_telegram_static.Telegram.test_risk_report_matches_risk_manager) ... ok
test_invalid_prices_ignored (test_trading_risk.PaperTraderMonitoring.test_invalid_prices_ignored) ... ok
test_other_market_prices_not_applied (test_trading_risk.PaperTraderMonitoring.test_other_market_prices_not_applied) ... ok
test_profit_survives_scale_out_in_final_report (test_trading_risk.PaperTraderMonitoring.test_profit_survives_scale_out_in_final_report) ... ok
test_scale_out_happens_once_and_moves_stop_to_breakeven (test_trading_risk.PaperTraderMonitoring.test_scale_out_happens_once_and_moves_stop_to_breakeven) ... ok
test_short_stop (test_trading_risk.PaperTraderMonitoring.test_short_stop) ... ok
test_stop_check_uses_previous_stop_not_the_just_ratcheted_one (test_trading_risk.PaperTraderMonitoring.test_stop_check_uses_previous_stop_not_the_just_ratcheted_one) ... ok
test_stop_loss_closes_with_loss_and_locks_pair (test_trading_risk.PaperTraderMonitoring.test_stop_loss_closes_with_loss_and_locks_pair) ... ok
test_take_profit (test_trading_risk.PaperTraderMonitoring.test_take_profit) ... ok
test_blocks_when_remaining_budget_is_tiny (test_trading_risk.RiskManagerRules.test_blocks_when_remaining_budget_is_tiny) ... ok
test_cap_is_dynamic_with_equity (test_trading_risk.RiskManagerRules.test_cap_is_dynamic_with_equity) ... ok
test_consecutive_losses_pause (test_trading_risk.RiskManagerRules.test_consecutive_losses_pause) ... ok
test_daily_loss_limit_blocks (test_trading_risk.RiskManagerRules.test_daily_loss_limit_blocks) ... ok
test_data_outage_blocks_new_entries (test_trading_risk.RiskManagerRules.test_data_outage_blocks_new_entries) ... ok
test_dynamic_kelly_never_exceeds_configured_ceiling_and_counts_zero_pnl_correctly (test_trading_risk.RiskManagerRules.test_dynamic_kelly_never_exceeds_configured_ceiling_and_counts_zero_pnl_correctly) ... ok
test_invalid_inputs (test_trading_risk.RiskManagerRules.test_invalid_inputs) ... ok
test_max_drawdown_pause (test_trading_risk.RiskManagerRules.test_max_drawdown_pause) ... ok
test_position_size_respects_budget_and_cap (test_trading_risk.RiskManagerRules.test_position_size_respects_budget_and_cap) ... ok
test_remaining_risk_shrinks_as_positions_fill_the_cap (test_trading_risk.RiskManagerRules.test_remaining_risk_shrinks_as_positions_fill_the_cap) ... ok
test_same_symbol_cannot_be_open_in_both_markets (test_trading_risk.RiskManagerRules.test_same_symbol_cannot_be_open_in_both_markets) ... ok
test_spot_is_long_only_and_uses_spot_fee (test_trading_risk.RiskManagerRules.test_spot_is_long_only_and_uses_spot_fee) ... ok
test_stop_and_target_derive_from_fill_price (test_trading_risk.RiskManagerRules.test_stop_and_target_derive_from_fill_price) ... ok
test_strategy_kill_switch_is_per_strategy (test_trading_risk.RiskManagerRules.test_strategy_kill_switch_is_per_strategy) ... ok
test_unknown_exchange_rules_block_when_required (test_trading_risk.RiskManagerRules.test_unknown_exchange_rules_block_when_required) ... ok
test_breakeven_at_1r_covers_costs (test_trading_risk.TradeManagement.test_breakeven_at_1r_covers_costs) ... ok
test_no_move_before_1r (test_trading_risk.TradeManagement.test_no_move_before_1r) ... ok
test_trailing_disabled (test_trading_risk.TradeManagement.test_trailing_disabled) ... ok
test_trailing_follows_after_2r_and_never_loosens (test_trading_risk.TradeManagement.test_trailing_follows_after_2r_and_never_loosens) ... ok

----------------------------------------------------------------------
Ran 198 tests in 51.740s

OK

```
