# PHASE 1 REPORT — Audit & Testing (AI QUANT X 7.2.0 → 7.2.1-dev)

**الحالة: Phase 1 غير مكتملة بالكامل.** المنطق الداخلي مُختبَر (216 اختباراً، 0 فشل)، لكن بيئة التدقيق **بلا شبكة** فلم يُشغَّل
شيء من: pytest، FastAPI/Uvicorn، Telegram، Binance العام، WebSocket، Docker. لذلك **لا يُنتقل إلى Phase 2** قبل تشغيل البنود
المذكورة في §5 على جهاز فيه إنترنت. لا ادعاء بأي ربحية أو Edge.

## 1. الحماية والتراجع (Rollback)
| البند | التفاصيل |
|---|---|
| نسخة أصلية | `backups/AI-QUANT-X-FINAL.original.zip` — SHA256 `9d3b4fa8002cd9bb650b36775538cf5a8db7b928afdc9e797e9e8b313922649d` |
| Git | commit أساس `28db31c` + وسم `legacy-core-7.2.0`، والتطوير على فرع `develop/quant-intelligence` |
| الرجوع | `git checkout legacy-core-7.2.0` يعيد النظام القديم حرفياً |

## 2. الملفات
**معدّلة:** `news_engine.py` (إصلاح خطأ، الواجهة العامة كما هي).
**مُنشأة:** `tests/test_news_engine.py` (11 اختباراً)، `tests/test_real_stack_smoke.py` (7 اختبارات تُتخطى تلقائياً بلا المكتبات الحقيقية)،
`scripts/phase1_live_checks.py` (فحص اتصال قراءة فقط لـBinance العام)، `PHASE1_REPORT.md`.
**لم يُمَس:** كل Legacy Core (المحاسبة، قاعدة البيانات، المخاطر، الاستراتيجيات، Backtest، FastAPI، Telegram، الإعدادات).

## 3. الخطأ المُصلَح ولماذا
`news_engine.py` (معطّل افتراضياً `NEWS_ENABLED=false`، لكن إن فُعّل يحجب صفقات):
1. المطابقة بالنص الجزئي: "ban" تُطابق **Bank / Urban / Banking**؛ "exploit" تُطابق Exploitation. ← الآن كلمات كاملة مع التصريفات (hack/hacked/banned…)، والعربية تبقى جزئية (بسبب البوادئ).
2. نسب الخبر للعملة بأول 3 أحرف: `sol`⊂solution، `ton`⊂Washington/Boston، `shi`⊂Shipping، `1000PEPEUSDT`→`100`. وفي المقابل عنوان "Bitcoin ETF…" لا يحتوي "btc" فلا يُنسب لـBTC أبداً. ← الآن الرمز بحروف كبيرة ككلمة كاملة (`SOL`، `$SOL`) + أسماء معروفة (Bitcoin، Solana…)، وإزالة `USDT` وبادئة `1000`.
نقاط التحقق: 11 اختباراً جديداً. التحقق الطفري: على الكود القديم تفشل الاختبارات عند الاستيراد (الدوال المساعدة غير موجودة) — وهذا دليل أضعف من اختبار سلوكي؛ السلوك الخاطئ القديم أثبتّه بتشغيل مباشر على 6 عناوين وعدة رموز قبل الإصلاح.

## 4. الاختبارات التي شُغِّلت فعلاً (Python 3.12.3، pandas 3.0.6، numpy 2.5.4، sklearn 1.9.1)
| الفحص | النتيجة |
|---|---|
| `compileall` | OK |
| `node --check pro_*.js` (7 ملفات) | OK |
| الأساس قبل أي تعديل: `unittest discover -s tests` | **198 OK** |
| بعد التعديل: نفس الأمر | **216 اختباراً: OK، 7 مُتخطاة (تحتاج fastapi/telegram الحقيقيين)، 0 فشل** |
| توافق Legacy | كل الـ198 اختباراً القديمة نجحت دون تعديل أي منها |

مقارنة الأداء قبل/بعد: **غير منطبقة** — لم يتغير أي منطق تداول أو إشارات أو مخاطر؛ لا Backtest جديد.

## 5. ما تعذّر تشغيله (يلزم جهاز فيه إنترنت)
```bash
git checkout develop/quant-intelligence
pip install -r requirements-dev.txt          # fastapi, aiohttp, telegram, websockets, nltk, pytest, httpx...
pytest -q                                     # يشغّل أيضاً الاختبارات المتخطاة
python scripts/phase1_live_checks.py          # Binance العام: legacy + endpoints المرحلة 2 + WebSocket
docker build -t aiqx . && docker run --rm -p 8080:8080 -e DASHBOARD_KEY=test aiqx   # ثم GET /health
```
أرسل المخرجات وأعالج أي فشل قبل Phase 2. إن كان `phase1_live_checks.py` يُرجع 451/403 على endpoints فاستضافتك محجوبة من Binance.

## 6. مشكلات متبقية (مرصودة بالقراءة، **لم تُعدَّل** حفاظاً على Legacy)
1. **Auto-Tune يقصر النظام على استراتيجية واحدة:** `engine.start()` يضع `config.STRATEGIES=(saved_strategy,)` بشكل دائم بعد إعادة التشغيل، والاختيار من عدة تجارب (خطر اختبارات متعددة). يخالف روح «الاحتفاظ بكل الاستراتيجيات» → يُعالَج في Phase 5 بعلم ميزة.
2. **فلتر المشاعر عام لكل العملات** (`sentiment_engine`، VADER) — مخالف لقاعدة «لا خبر عام يؤثر على الجميع» → Phase 7.
3. ردود الـmiddleware المبكرة (401/403/429/تحويل إلى /login) **بلا** ترويسات الأمان (`X-Frame-Options`…). منخفض الخطورة.
4. `start()` لا يحمي `ml_task`/`ws_task` من الإنشاء المزدوج لو استُدعي مرتين (لا يحدث في المسار الحالي).
5. اختلاف الإصدارات: Docker على Python 3.11 وأنا اختبرت على 3.12؛ pandas 2.x لم يُجرَّب.
6. الـBacktest القديم متفائل (لا ML/أخبار/دفتر أوامر/Funding filter) — موثق مسبقاً، يُعالَج في Phase 4 عبر محرك **إضافي** لا بديل.
7. القيود المعروفة لمحاكاة Futures (لا MMR متدرج، Mark Price = آخر سعر) — Phase 4.
