# PHASE 2 REPORT — Market Data Intelligence (طبقة البيانات فقط)

**الحالة:** الكود والاختبارات المنطقية مكتملة (258 اختباراً OK). **لم يُختبر أي شيء على Binance الحي** (بيئة البناء بلا شبكة)،
لذلك صيغ الـpayloads مبنية على التوثيق وتحتاج تحققاً حياً (§5). لا ادعاء بأي Edge أو ربحية: هذه المرحلة تجمع بيانات فقط، ولا تغيّر أي قرار تداول.

## 1. الملفات
**أُنشئت:** `edge/{__init__,flags,client,store,orderflow,liquidations,historical,collector,context}.py`،
`scripts/edge_collect.py`، `scripts/edge_inspect.py`، `tests/test_edge_data.py` (42 اختباراً)، هذا التقرير.
**عُدِّلت:** `.env.example` (أسطر معلّقة مضافة فقط). **لم يُمَس:** كل Legacy Core (يثبته اختبار: لا ملف Legacy يستورد `edge`).

## 2. ما بُني ولماذا
| المكوّن | الوظيفة | قرار تصميم |
|---|---|---|
| `flags.py` | 6 أعلام تفعيل (ADVANCED_DATA، LIGHTGBM، META_LABELING، ORDER_FLOW، MARKET_REGIME، ADVANCED_BACKTEST) | كلها OFF افتراضياً؛ للأعلام اعتماديات؛ اسم مجهول يرفع خطأ |
| `client.py` | OI حالي/تاريخي، Long/Short (3 أنواع)، Taker volume، Mark/Index/Premium، Funding تاريخي، aggTrades بترقيم صفحات | أي قيمة غير صالحة (NaN، نص، سالب) ترفع `EdgeDataError`؛ لا قيم افتراضية؛ aggTrades يعيد `complete` ليُعرف إن كانت النافذة ناقصة |
| `store.py` | SQLite **منفصل** (`edge_data.db`) لا يلمس دفتر الحركات | كل صف له `available_at` (متى كان يمكن معرفته)؛ الاستعلام بـ`as_of_ms` لا يُرجع إلا ما كان معروفاً → لا look-ahead |
| `orderflow.py` | CVD، Taker imbalance، تغيّر OI، رباعية السعر/OI (LONG_BUILDUP…) | دوال نقية قابلة للتفسير؛ الشمعة غير المغلقة تُستبعد |
| `liquidations.py` | تحليل `!forceOrder@arr` + مستهلك WebSocket بإعادة اتصال | موثّق: Binance تبث تصفية واحدة/ثانية/رمز كحد أقصى ⇒ الأرقام **حد أدنى** |
| `historical.py` | محلّلات أرشيف data.binance.vision (metrics، fundingRate، aggTrades) | **غير مُتحقَّق على ملفات حقيقية** (اختبارات اصطناعية فقط) |
| `collector.py` / `edge_collect.py` | دورة جمع، أخطاء معزولة لكل endpoint | لا يُخزَّن CVD إلا لنافذة كاملة ودلاء مغلقة (الصف يُدخل مرة واحدة فلا يُصحَّح لاحقاً) |
| `context.py` | لقطة ميزات Point-in-Time لرمز | `None` + قائمة `missing`/`stale`؛ **غير موصولة** بمسار التداول (مقصود) |

افتراض متحفّظ موثّق: حقل `timestamp` في سلاسل الفترات قد يعني بداية الدلو أو نهايته (غير مؤكَّد)، لذا `available_at = ts + طول الفترة`.
للبيانات الحية: `max(القاعدة، وقت الجلب)` — لا يمكن أن نعرف شيئاً قبل أن نسأل عنه.

## 3. الاختبارات (شُغِّلت فعلاً: Python 3.12.3، بلا شبكة)
| الفحص | النتيجة |
|---|---|
| `python -m unittest discover -s tests` | **258 اختباراً: OK، 7 متخطاة، 0 فشل** (216 قديمة/المرحلة 1 + 42 جديدة) |
| اختبارات Legacy الـ198 | نجحت دون تعديل أي منها |
| `compileall` | OK |
| تحقق طفري (6 أخطاء حُقنت في نسخة معزولة) | كلها كُشفت: عكس إشارة CVD، إزالة حاجز `as_of`، تخزين CVD جزئي، تسرب الدلو المفتوح، تجاهل وقت الجلب، عكس اتجاه التصفية. الأساس ينجح قبلها وبعدها |
تغطية الـ42: الأعلام، التحقق من المدخلات، رفض NaN والـpayload الفاسد، ترقيم aggTrades (`fromId` بلا `startTime`)، إشارة CVD، حاجز Look-ahead في المخزن وفي اللقطة، عزل الأخطاء، إعادة اتصال WebSocket، المحلّلات، وعزل الحزمة (لا endpoints للأوامر/الحساب، لا مفاتيح، لا استيراد لقاعدة التداول).
ملاحظة صدق: أول تشغيل لفحص الطفرات أعطى نتائج ملوّثة بسبب كاش `.pyc` (تغيّر النص دون تغيّر الحجم)؛ أُعيد بعد تعطيل الكاش وذُكرت النتائج الصحيحة فقط.

## 4. مقارنة قبل/بعد
**غير منطبقة.** لا منطق تداول/إشارات/مخاطر تغيّر، ولا Backtest جديد، ولا ادعاء بتحسّن أداء. القيمة تظهر لاحقاً فقط إن أثبتت ميزات هذه البيانات فائدة خارج العينة (المراحل 3–4).

## 5. ما لم يُختبر ويلزم على جهازك
1. صيغ ردود Binance الفعلية (أسماء الحقول) والأحمال/الأوزان.
2. `openInterestHist` وما شابهه: حسب علمي يُتاح لآخر ~30 يوماً فقط (يلزم تأكيده) ⇒ لا تاريخ أطول من هذا إلا عبر الأرشيف أو من يوم بدء الجمع.
3. WebSocket `!forceOrder@arr` وتحليل أرشيف data.binance.vision.
4. **CVD عبر REST محدود:** نافذة 10 دقائق لرمز نشط مثل BTC قد تتجاوز 10 آلاف aggTrade ⇒ `incomplete_cvd` ولا يُخزَّن شيء. هذا يُقاس عملياً بتشغيل المُجمِّع؛ إن تكرر فالحل الصحيح تيار WebSocket `aggTrade` (مرحلة 2b)، لا زيادة الصفحات.
5. Python 3.11/Docker، pandas 2.x، pytest الحقيقي.
```bash
git checkout develop/quant-intelligence && pip install -r requirements-dev.txt && pytest -q
python scripts/phase1_live_checks.py
FF_ADVANCED_DATA=true EDGE_SYMBOLS=BTCUSDT,ETHUSDT python scripts/edge_collect.py     # اتركه 15-30 دقيقة ثم Ctrl+C
python scripts/edge_inspect.py                                                        # أرسل مخرجاته
```

## 6. مشكلات متبقية
- بيانات الأرشيف التاريخي مُحلَّلة لكن **لا يوجد سكربت تنزيل بعد** (`url_for` فقط) — يُضاف بعد تأكيد صيغة الملف الأول على جهازك.
- الحماية من تجاوز حدود الطلبات تعتمد على `MarketData._get` (تهدئة 429)؛ لم تُقدَّر الأوزان لقوائم رموز طويلة (الافتراضي 3 رموز).
- Auto-Tune (يقصر الاستراتيجيات على واحدة) وفلتر المشاعر العام ما زالا قائمين → المرحلتان 5 و7.
- لا اختبار لسكربت `edge_collect.py` نفسه (يحتاج aiohttp/websockets الحقيقيين)؛ منطقه الأساسي مختبَر عبر `collect_once` و`run_stream`.
